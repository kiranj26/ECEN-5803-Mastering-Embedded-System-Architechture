/* ========================================================================== */
/*                                                                            */
/*  dhry.h                                                              */
/*   (c) 2012 Author                                                          */
/*                                                                            */
/*   Description                                                              */
/*                                                                            */
/* ========================================================================== */


 
#ifndef _DHRY_H
#define _DHRY_H
 
#define LOOPS   512
 
#ifdef __cplusplus
extern "C" {
#endif
 
extern void Proc0 (void);
 
#ifdef __cplusplus
}
#endif
 
#endif

